
import java.sql.Connection;
import java.util.Scanner; 

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import org.hsqldb.Server;
public class FinalProject {
	public static void main(String[] args) throws ClassNotFoundException, SQLException
	{

		Server hsqlServer = null;

		try {

			hsqlServer = new Server();
			hsqlServer.setLogWriter(null);
			hsqlServer.setSilent(true);
			// Update the database name and path to your own!
			hsqlServer.setDatabaseName(0, "ABC");
			hsqlServer.setDatabasePath(0, "file:C:/Users/HyeSung/Desktop/ABC/ABC");
			// Start the database!
			hsqlServer.start();
			Connection connection = null;


			try {
				// Getting a connection to the newly started database
				Class.forName("org.hsqldb.jdbcDriver");
				// Default user of the HSQLDB is 'sa' with an empty password
				connection = DriverManager.getConnection(
						"jdbc:hsqldb:file:C:/Users/HyeSung/Desktop/ABC/ABC", "SA", "");
				//loop - 
				boolean done = false;
				while(done == false){
					System.out.println();
					System.out.println();
					System.out.println("Welcome to LeagueOfLegends Info Program!!");
					System.out.println("Please select what you'd like to do!");
					System.out.println("1) Take a look at all the champion names in the program");
					System.out.println("2) Take a look at the info of the champion");
					System.out.println("3) Display all the ban rates of all the champions in the program");
					System.out.println("4) Display the ban rate of a chosen champion");
					System.out.println("5) Look at the champion that has the chosen banRate");
					System.out.println("6) See which champion has highest ban rate?");
					System.out.println("7) Update a champion of your selection");
					System.out.println("8) Look at all the season info of all the champions in the program");
					System.out.println("9) Look at the highest Win Rate of a champion of this season");
					System.out.println("10) Update a champion of your selection");
					System.out.println("15) Exit");
					System.out.println();
					Scanner sc = new Scanner(System.in);
					String optionChosen = sc.nextLine();

					if(optionChosen.equals ("1")){
						// Can execute your SQL commands here!
						ResultSet rs = connection.prepareStatement(
								//1 display all the names of the champions in the program
								"SELECT Name from Champions;"
								).executeQuery();
						ResultSetMetaData rsmd = rs.getMetaData();
						int numberOfColumns = rsmd.getColumnCount();
						for (int i = 1; i <= numberOfColumns; i++) {
							if (i > 1)
								System.out.print(",\t\t");
							String columnName = rsmd.getColumnName(i);
							System.out.print(columnName);
						}
						System.out.println("");
						while (rs.next()) {
							for (int i = 1; i <= numberOfColumns; i++) {
								if (i > 1)
									System.out.print(",\t\t");
								String columnValue = rs.getString(i);
								System.out.print(columnValue);
							}
							System.out.println("");
						}


					}
					if(optionChosen.equals ("2")){
						//2 display all the info of the chosen champion
						System.out.println("Please enter the name of the champion you would like to see!!");
						Scanner a = new Scanner(System.in);
						String chosenChamp = sc.nextLine();
						System.out.println("You've chosen" + chosenChamp);

						ResultSet rs =connection.prepareStatement(
								"SELECT * from Champions   WHERE Name = '" + chosenChamp + "';"
								).executeQuery();


						ResultSetMetaData rsmd = rs.getMetaData();
						int numberOfColumns = rsmd.getColumnCount();
						for (int i = 1; i <= numberOfColumns; i++) {
							if (i > 1)
								System.out.print(",\t\t");
							String columnName = rsmd.getColumnName(i);
							System.out.print(columnName);
						}
						System.out.println("");
						while (rs.next()) {
							for (int i = 1; i <= numberOfColumns; i++) {
								if (i > 1)
									System.out.print(",\t\t");
								String columnValue = rs.getString(i);
								System.out.print(columnValue);
							}
							System.out.println("");
						}
					}


					if(optionChosen.equals ("3")){
						//3 display all the champions and banRates in Bans
						ResultSet rs = connection.prepareStatement(
								"SELECT * from Bans;"
								).executeQuery();

						ResultSetMetaData rsmd = rs.getMetaData();
						int numberOfColumns = rsmd.getColumnCount();
						for (int i = 1; i <= numberOfColumns; i++) {
							if (i > 1)
								System.out.print(",\t\t");
							String columnName = rsmd.getColumnName(i);
							System.out.print(columnName);
						}
						System.out.println("");
						while (rs.next()) {
							for (int i = 1; i <= numberOfColumns; i++) {
								if (i > 1)
									System.out.print(",\t\t");
								String columnValue = rs.getString(i);
								System.out.print(columnValue);
							}
							System.out.println("");
						}
					}
					if(optionChosen.equals ("4")){
						//4 display the type of the chosen champion
						System.out.println("Please enter the type of the champion you would like to see!!");
						Scanner a = new Scanner(System.in);
						String chosenType = sc.nextLine();
						System.out.println("You've chosen " + chosenType);
						ResultSet rs = connection.prepareStatement(
								"SELECT banRate from Bans   WHERE Name = '" +chosenType + "'  ;"
								).executeQuery();
						

						ResultSetMetaData rsmd = rs.getMetaData();
						int numberOfColumns = rsmd.getColumnCount();
						for (int i = 1; i <= numberOfColumns; i++) {
							if (i > 1)
								System.out.print(",\t\t");
							String columnName = rsmd.getColumnName(i);
							System.out.print(columnName);
						}
						System.out.println("");
						while (rs.next()) {
							for (int i = 1; i <= numberOfColumns; i++) {
								if (i > 1)
									System.out.print(",\t\t");
								String columnValue = rs.getString(i);
								System.out.print(columnValue + "%");
							}
							System.out.println("");
						}
					}
					
					if(optionChosen.equals ("5")){
						//4 display the type of the chosen champion
						System.out.println("Please enter the type of the champion you would like to see!!");
						Scanner a = new Scanner(System.in);
						int chosenBanRate = sc.nextInt();
						System.out.println("You've chosen " + chosenBanRate);
						ResultSet rs = connection.prepareStatement(
								"SELECT Name from Bans   WHERE banRate = '" +chosenBanRate + "';"
								).executeQuery();
						System.out.print("Champions that have the Ban Rate of " + chosenBanRate + "are following ");

						ResultSetMetaData rsmd = rs.getMetaData();
						int numberOfColumns = rsmd.getColumnCount();
						for (int i = 1; i <= numberOfColumns; i++) {
							if (i > 1)
								System.out.print(",\t\t");
							
							
						}
						System.out.println("");
						while (rs.next()) {
							for (int i = 1; i <= numberOfColumns; i++) {
								if (i > 1)
									System.out.print(",\t\t");
								String columnValue = rs.getString(i);
								System.out.print(columnValue);
							}
							System.out.println("");
						}
					}
					
					if(optionChosen.equals ("6")){
						//6 see which champion has the highest ban rate
						ResultSet rs = connection.prepareStatement(
								"SELECT MAX(BanRate) from Bans;"
								).executeQuery();
						System.out.print("The highest ban rate of the season is....!!" );
						System.out.println("If you'd like to see which champion has the highest Ban Rate, please search by this value!!");


						ResultSetMetaData rsmd = rs.getMetaData();
						int numberOfColumns = rsmd.getColumnCount();
						for (int i = 1; i <= numberOfColumns; i++) {
							if (i > 1)
								System.out.print(",\t\t");
						
						}
						System.out.println("");
						while (rs.next()) {
							for (int i = 1; i <= numberOfColumns; i++) {
								if (i > 1)
									System.out.print(",\t\t");
								String columnValue = rs.getString(i);
								System.out.print(columnValue + "%");
							}
							System.out.println("");
						}
					}
					if(optionChosen.equals ("7")){
						//7 updating a champion of the selection
						System.out.println("Please type in the name of the champion you'd like to UPDATE");
						Scanner a = new Scanner(System.in);
						String champToUpdate = sc.nextLine();
						System.out.println();
						System.out.println("Which column would you like to update?? (NAME, TYPE, DEFENSEPOWER, ATTACKPOWER, BESTAGAINST, WORSTAGAINST)");
						Scanner b = new Scanner(System.in);
						String columnToUpdate = sc.nextLine();
						System.out.println();
						System.out.println("What do you want it to be?");
						Scanner c = new Scanner(System.in);
						String value = sc.nextLine();
						System.out.println();

						connection.prepareStatement(
								"UPDATE Champions SET '" + columnToUpdate + "' = '" + value  + "' WHERE Name = '" + champToUpdate + "';"
								).execute();
						System.out.println("You've updated " + champToUpdate);
					}
					
					if(optionChosen.equals ("8")){
						// Can execute your SQL commands here!
						ResultSet rs = connection.prepareStatement(
								//8 Look at all the info of each champion from the season
								"SELECT * from Season;"
								).executeQuery();
						ResultSetMetaData rsmd = rs.getMetaData();
						int numberOfColumns = rsmd.getColumnCount();
						for (int i = 1; i <= numberOfColumns; i++) {
							if (i > 1)
								System.out.print(",\t\t");
							String columnName = rsmd.getColumnName(i);
							System.out.print(columnName);
						}
						System.out.println("");
						while (rs.next()) {
							for (int i = 1; i <= numberOfColumns; i++) {
								if (i > 1)
									System.out.print(",\t\t");
								String columnValue = rs.getString(i);
								System.out.print(columnValue);
							}
							System.out.println("");
						}


					}
					if(optionChosen.equals ("9")){
						//9 See the highest win rate of the season
						ResultSet rs = connection.prepareStatement(
								"SELECT MAX(WinRate) from Season;"
								).executeQuery();
						System.out.print(" % is the highest Win Rate of the season of one champion.");
						System.out.println("If you'd like to see which champion has the highest Win Rate, please search by this value!!");

						ResultSetMetaData rsmd = rs.getMetaData();
						int numberOfColumns = rsmd.getColumnCount();
						for (int i = 1; i <= numberOfColumns; i++) {
							if (i > 1)
								System.out.print(",\t\t");
							String columnName = rsmd.getColumnName(i);
							System.out.print(columnName);
						}
						System.out.println("");
						while (rs.next()) {
							for (int i = 1; i <= numberOfColumns; i++) {
								if (i > 1)
									System.out.print(",\t\t");
								String columnValue = rs.getString(i);
								System.out.print(columnValue);
							}
							System.out.println("");
						}
					}


					if(optionChosen.equals ("15")){
						System.out.println("BYE BYE!!!!!!");
						done = true;
					} 


				}
			} finally {
				// Closing the connection
				if (connection != null)
					connection.close();
			}
		} finally {
			// Closing the server
			if (hsqlServer != null)
				hsqlServer.stop();
		}
	}
}